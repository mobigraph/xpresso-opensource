var xpresso = new Xpresso({ "apiKey":"6hSjEEYWVHTmSUUwvwjJzTpX8_zq8noEYq2-_r5ABnkq98vSw1jvHFKncRlYUA-C","countryCode": "in" });
xpresso.setAvatarByteCode(localStorage.getItem("avByteCode"))